import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
import random

def emd(vector_1, vector_2, num_candidates):
    dirt = 0.
    for i in range(num_candidates-1):
        surplus = vector_1[i] - vector_2[i]
        dirt += abs(surplus)
        new = vector_1[i+1]+ surplus
        vector_1[i+1] = new
    return dirt

def emd_matrix(mat1,mat2,column_candidates=True):
    num_canidates=len(mat1)
    costs=[]
    mat1_np=np.array(mat1, dtype='f')
    mat2_np=np.array(mat2, dtype='f')
    if mat1_np.shape!=mat2_np.shape:
        print("ERROR: Dimensions of matrices do not match")
        exit()
    if column_candidates==False:
        mat1_np=mat1_np.transpose()
        mat2_np = mat2_np.transpose()
    #print(mat1_np)
    #print(mat2_np)
    for i in range(num_canidates):
        cost=[]
        for j in range(num_canidates):
            #print(mat1_np[:,i])
            #print(mat2_np[:, j])
            cost.append(emd(mat1_np[:,i].copy(),mat2_np[:,j].copy(),num_canidates))
            #print(cost)
        costs.append(cost)
    costs= np.array(costs)
    #print(costs)
    row_ind, col_ind = linear_sum_assignment(costs)
    return costs[row_ind, col_ind].sum()

M1=[[0,0.5,0.5],[0.5,0.5,0],[0.5,0,0.5]]
M2=[[1/3,1/3,1/3],[2/3,0,1/3],[0,2/3,1/3]]

print(emd_matrix(M1,M2,column_candidates=True))
