import mapel
import matplotlib.pyplot as plt
import math
import sys
import numpy as np


def map_diameter(c):
    """ Compute the diameter """
    return 1. / 3. * float((c + 1) * (c - 1))


def l2(vector_1, vector_2):
    """ compute L2 metric """
    return math.pow(sum([math.pow((vector_1[i] - vector_2[i]), 2)
                         for i in range(len(vector_1))]), 0.5)


if __name__ == "__main__":

    num_candidates = int(sys.argv[1])
    experiment_id = "skeleton_" + str(num_candidates)

    m = num_candidates
    n = 100

    experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                          elections='import',
                                          distances='import',
                                          coordinates='import')

    raw_names = ["ID", "UN", "AN", "ST", "WAL", "CON", "CAT", "MID",
                 "A_6"]
    names = ["ID", "UN", "AN", "ST", "WAL", "CON", "CAT", "MID",
             "M2W"]

    matrix_new = np.zeros([len(names), len(names)])
    matrix_new_2 = np.zeros([len(names), len(names)])

    fig, ax = plt.subplots()
    x_values = names
    y_values = names

    for i, family_id_1 in enumerate(raw_names):
        for j, family_id_2 in enumerate(raw_names):
            if i != j:
                if j > i:
                    c = float(experiment.distances[family_id_1][family_id_2])
                    c /= map_diameter(num_candidates)
                    c = round(c, 2)

                    matrix_new[i][j] = c
                    if (i+j) % 2 == 0:
                        matrix_new_2[i][j] = -0.87
                    else:
                        matrix_new_2[i][j] = -0.87/2.
                    color = "black"
                    # if c >= 0.75:
                    #     color = "white"
                    ax.text(j, i, str(c), va='center', ha='center', color=color, rotation=25,
                            size=12)

                elif j < i:
                    euclidean_distance = experiment.distances[family_id_1][family_id_2]
                    euclidean_distance /= map_diameter(num_candidates)
                    embedded_distance = l2(experiment.coordinates[family_id_1],
                                           experiment.coordinates[family_id_2])
                    embedded_distance /= l2(
                        experiment.coordinates['ID'],
                        experiment.coordinates['UN'])
                    c = embedded_distance / euclidean_distance
                    c = round(c, 2)

                    if family_id_1 == 'MID' and family_id_2 == 'WAL':
                        print(euclidean_distance)
                        print(embedded_distance)

                    margin = abs(1.-c)
                    matrix_new_2[i][j] = margin

                    color = "black"
                    if margin > 0.5:
                        color = "white"
                    ax.text(j, i, str(c), va='center', ha='center', color=color, rotation=-25, size=12)

    # my_cmap = plt.cm.Blues
    my_cmap = mapel.custom_div_cmap(colors=['white', 'oldlace', 'white', 'cornflowerblue', 'blue'])

    ax.matshow(matrix_new_2, cmap=my_cmap)

    # Major ticks every 20, minor ticks every 5
    print(len(raw_names))
    minor_ticks = np.arange(0.5, 9.5, 1)
    ax.plot([1, 0], [0, 1], transform=ax.transAxes, color='black', linewidth=1)

    ax.set_xticks(minor_ticks, minor=True)

    ax.set_yticks(minor_ticks, minor=True)

    ax.grid(which='minor')

    y_axis = np.arange(0, len(names), 1)
    x_axis = np.arange(0, len(names), 1)

    ax.set_yticks(y_axis)
    ax.set_yticklabels(y_values, rotation=25, size=10)

    ax.set_xticks(x_axis)
    ax.set_xticklabels(x_values, rotation=75, size=10)

    import os

    saveas = 'skeleton_matrix_10_distortion'

    file_name = os.path.join(os.getcwd(), "images", str(saveas) + ".png")
    plt.savefig(file_name, bbox_inches='tight')

    plt.show()












