#!/usr/bin/env python

import os
import sys
import math
import mapel
import mapel.voting.elections.group_separable as gs
import mapel.voting.elections.mallows as mall
import mapel.voting.elections.single_crossing as sc
import mapel.voting.elections.single_peaked as sp
import mapel.voting.elections.impartial as ic
import mapel.voting.objects.Election as elec

import emd as emd
import matplotlib.pyplot as plt
import statistics
import numpy as np
import copy
import tikzplotlib
import mallowsmatrix as mmat



def UN(m):
    UN = []
    for i in range(m):
        UN.append([1.0 / m] * m)
    return UN


def election_to_pos(e, m):
    P = [[0 for i in range(m)] for j in range(m)]
    for v in e:
        for i, c in enumerate(v):
            P[int(i)][int(c)] = P[int(i)][int(c)] + 1
    for i in range(m):
        for j in range(m):
            P[int(i)][int(j)] = P[int(i)][int(j)] / len(e)
    return P

def election_distance_matrix(mat_function, election_func, name, num_elections, max_voters, voter_step_size,
                             candidate_list, mallowsBool=False, lphi=1, boolrelphi=True,voter_start=2,params=None):
    if mallowsBool:
        name=name+str(lphi)+str(boolrelphi)
    num_candidates = len(candidate_list)
    mean = [[0 for i in range(voter_start, max_voters, voter_step_size)] for j in range(num_candidates)]
    maxx = [[0 for i in range(voter_start, max_voters, voter_step_size)] for j in range(num_candidates)]
    minn = [[0 for i in range(voter_start, max_voters, voter_step_size)] for j in range(num_candidates)]
    # for i, m in enumerate(np.linspace(10, 100, k, dtype=int)):
    for j, m in enumerate(candidate_list):
        if mallowsBool and boolrelphi:
            phi = mall.phi_from_relphi(m, lphi)
        else:
            phi=lphi
        for i, n in enumerate(range(voter_start, max_voters, voter_step_size)):
            print(n)
            elections = []
            for t in range(num_elections):
                if mallowsBool:
                    elections.append(election_func(n, m, params={'phi':phi, 'weight':0}))
                elif not params==None :
                    elections.append(election_func(n, m,params=params))
                else:
                    elections.append(election_func(n, m))
            if mallowsBool:
                matrix = mat_function(m, {'norm-phi':lphi, 'weight':0}, boolrelphi)
            else:
                matrix = mat_function(m)
            distances = []
            for el in elections:
                # print()
                election_mat = election_to_pos(el, m)
                distances.append(emd.emd_matrix(election_mat, matrix) / ((1 / 3) * (m * m - 1)))
            mean[j][i] = statistics.mean(distances)
            maxx[j][i] = np.quantile(distances,0.9)
            minn[j][i] = np.quantile(distances,0.1)

    coll = ['red', 'blue', 'green', 'orange', 'black']
    for j, m in enumerate(candidate_list):
        color = coll[j]
        plt.plot(list(range(voter_start, max_voters, voter_step_size)), mean[j], label='Mean ' + str(m), linestyle='solid',
                 color=color)
        plt.plot(list(range(voter_start, max_voters, voter_step_size)), maxx[j], label='90th Quantil' + str(m), linestyle='dashed',
                 color=color)
        plt.plot(list(range(voter_start, max_voters, voter_step_size)), minn[j], label='10th Quantil ' + str(m), linestyle='dotted',
                 color=color)
        plt.legend()
    plt.xlabel('n')
    plt.ylabel('normalized distance')
    plt.savefig("./img/" + name + 'cityDistancee' + str(num_elections) + '.png')
    plt.close()
    return mean[-1]


def matrix_compassdist(mat_function, steps, name, mallowsBool=False, lphi=1, boolrelphi=True,linetype='solid'):
    t = steps
    ar = [[0 for i in range(t)] for j in range(6)]
    for j in range(t):
        m = 2 * j + 4
        print('step')
        print(m)
        ID = []
        UN = []
        AN = []
        ST = []
        for i in range(m):
            tmp = [0] * m
            tmp[i] = 1
            ID.append(tmp)
            UN.append([1.0 / m] * m)
            tmpp = [0] * m
            tmpp[i] = 0.5
            tmpp[m - i - 1] = 0.5
            AN.append(tmpp)
            if i < (m / 2):
                tmp1 = [2 / m] * int(m / 2)
                tmp2 = [0] * int(m / 2)
                ST.append(tmp1 + tmp2)
            else:
                tmp1 = [0] * int(m / 2)
                tmp2 = [2 / m] * int(m / 2)
                ST.append(tmp1 + tmp2)
        norm = (1 / 3) * (m * m - 1)
        if mallowsBool:
            mat = mat_function(m, {'norm-phi':lphi, 'weight':0}, boolrelphi)
        else:
            mat = mat_function(m)

        ar[0][j] = emd.emd_matrix(ID, mat, m) / norm
        ar[1][j] = emd.emd_matrix(UN, mat, m) / norm
        ar[2][j] = emd.emd_matrix(AN, mat, m) / norm
        ar[3][j] = emd.emd_matrix(ST, mat, m) / norm
        ar[4][j] = ar[0][j] + ar[1][j]
        ar[5][j] = ar[2][j] + ar[3][j]
    colors = ['darkred', 'darkorange', 'forestgreen', 'dodgerblue']
    for i, m in enumerate(['ID', 'UN', 'AN', 'ST']):
        plt.plot(list(range(4, 2 * (t - 1) + 4 + 1, 2)), ar[i], label=str(m),linestyle=linetype,color=colors[i])
        plt.legend()
    plt.xlabel('number of candidates')
    plt.ylabel('normalized positionwise distance')
    #plt.savefig('./img/distCompasses_' + name + str(steps) + str(boolrelphi)+ str(lphi)+ '.png')
    #tikzplotlib.save('./img/distCompasses_' + name + str(steps) + str(boolrelphi)+ str(lphi)+ '.tex', encoding='utf-8')

def distances(candidate_list,relative=False):
    matrix_list=[]
    for j, m in enumerate(candidate_list):
        print(m)
        matrices=[]
        matrices.append(elec.get_fake_vectors_single('identity', m, 0))
        matrices.append(elec.get_fake_vectors_single('uniformity', m, 0))
        matrices.append(elec.get_fake_vectors_single('stratification', m, 0))
        matrices.append(elec.get_fake_vectors_single('antagonism', m, 0))
        matrices.append(sp.get_conitzer_matrix(m))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi':0.2, 'weight':0}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.4, 'weight': 0}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.6, 'weight': 0}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.8, 'weight': 0}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi':0.2, 'weight':0.25}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.4, 'weight': 0.25}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.6, 'weight': 0.25}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.8, 'weight': 0.25}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi':0.2, 'weight':0.5}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.4, 'weight': 0.5}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.6, 'weight': 0.5}))
        matrices.append(mall.get_mallows_matrix(m, {'norm-phi': 0.8, 'weight': 0.5}))
        matrices.append(elec.get_fake_multiplication(m, {'alpha': 0.2}, "conitzer_path").transpose())
        matrices.append(elec.get_fake_multiplication(m, {'alpha': 0.4}, "conitzer_path").transpose())
        matrices.append(elec.get_fake_multiplication(m, {'alpha': 0.6}, "conitzer_path").transpose())
        matrices.append(elec.get_fake_multiplication(m, {'alpha': 0.8}, "conitzer_path").transpose())
        matrix_list.append(matrices)
    print('DONE COMPUTING MATRICES')
    print(len(matrix_list))
    print(len(matrix_list[0]))
    num_matrices=len(matrix_list[0])
    distances_extreme=np.zeros((num_matrices, num_matrices))
    distance_diff=np.zeros((num_matrices, num_matrices))
    max_distances=[0 for j in range(len(candidate_list))]
    norm = (1 / 3) * (candidate_list[-1] * candidate_list[-1] - 1)
    for i in range(num_matrices):
        for t in range(i, num_matrices):
            distances_extreme[i, t] = emd.emd_matrix(matrix_list[-1][i], matrix_list[-1][t], candidate_list[-1]) / norm
    #print(distances_extreme)
    for j,m in enumerate(candidate_list):
        print(m)
        norm = (1 / 3) * (m * m - 1)
        for i in range(num_matrices):
            for t in range(i+1,num_matrices):
                if relative:
                    distance_diff[i,t]=abs(distances_extreme[i,t]-emd.emd_matrix(matrix_list[j][i], matrix_list[j][t], m) / norm)/distances_extreme[i,t]
                else:
                    distance_diff[i, t] = abs(
                        distances_extreme[i, t] - emd.emd_matrix(matrix_list[j][i], matrix_list[j][t], m) / norm)
        max_distances[j]=distance_diff.max()
    plt.plot(candidate_list, max_distances)
    plt.xlabel('number of candidates')
    plt.ylabel('maximum difference normalized positionwise distance')
    #plt.savefig('./img/robustnessLargerRel.png')
    #tikzplotlib.save('./img/robustnessLargerRel.tex',encoding='utf-8')

def mallows_variance():
    max_voters = 201
    voter_step_size = 5
    candidate_list = [50]
    num_elections = 600

    meanMal1 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.1,
                                        boolrelphi=True)
    meanMal2 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.2,
                                        boolrelphi=True)
    meanMal3 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.3,
                                        boolrelphi=True)
    meanMal4 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.4,
                                        boolrelphi=True)
    meanMal5 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.5,
                                        boolrelphi=True)
    meanMal6 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.6,
                                        boolrelphi=True)
    meanMal7 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.7,
                                        boolrelphi=True)
    meanMal8 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.8,
                                        boolrelphi=True)
    meanMal9 = election_distance_matrix(mall.get_mallows_matrix, mall.generate_mallows_election, 'mallows', num_elections,
                                        max_voters, voter_step_size, candidate_list, mallowsBool=True, lphi=0.9,
                                        boolrelphi=True)
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal1, label='relphi 0.1')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal2, label='relphi 0.2')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal3, label='relphi 0.3')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal4, label='relphi 0.4')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal5, label='relphi 0.5')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal6, label='relphi 0.6')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal7, label='relphi 0.7')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal8, label='relphi 0.8')
    plt.plot(list(range(2, max_voters, voter_step_size)), meanMal9, label='relphi 0.9')
    plt.legend()
    plt.xlabel('n')
    plt.ylabel('normalized mean distance')
    plt.savefig("./img/overviewcityDistanceMallowsRelphi" + str(num_elections) + '.png')
    plt.close()

full=False
#To also reproduceour experiments involving the Mallows model with more than 30 candidates please uncomment the following four lines
#Warning: You will need 50GB of RAM and hard disk storage for this
#full=True
#m=40
#S=mmat.generateVoteSwapArray(m)
#mmat.generatePositionArray(m, S)

#Figure 6
steps=150
matrix_compassdist(sp.get_conitzer_matrix,steps,'conitzer',linetype='solid')
matrix_compassdist(sp.get_walsh_matrix,steps,'walsh',linetype='dashed')
plt.savefig('./img/Fig6.png')
plt.close()


#Figure 7
matrix_compassdist(gs.get_gs_caterpillar_matrix,steps,'GS')
plt.savefig('./img/Fig7.png')
plt.close()

#Figure 8
if full:
    steps=49
else:
    steps=14
matrix_compassdist(mall.get_mallows_matrix, steps, 'mallows', mallowsBool=True, lphi=0.25, boolrelphi=False,linetype='solid')
matrix_compassdist(mall.get_mallows_matrix, steps, 'mallows', mallowsBool=True, lphi=0.5, boolrelphi=False,linetype='dashed')
matrix_compassdist(mall.get_mallows_matrix, steps, 'mallows', mallowsBool=True, lphi=0.75, boolrelphi=False,linetype='dotted')
plt.savefig('./img/Fig8.png')
plt.close()

#Figure 9
matrix_compassdist(mall.get_mallows_matrix, steps, 'mallows', mallowsBool=True, lphi=0.25, boolrelphi=True,linetype='solid')
matrix_compassdist(mall.get_mallows_matrix, steps, 'mallows', mallowsBool=True, lphi=0.5, boolrelphi=True,linetype='dashed')
matrix_compassdist(mall.get_mallows_matrix, steps, 'mallows', mallowsBool=True, lphi=0.75, boolrelphi=True,linetype='dotted')
plt.savefig('./img/Fig9.png')
plt.close()

#Figure 10
if full:
    upperbound=101
else:
    upperbound=31
distances(list(range(4, upperbound, 2)),relative=True)
distances(list(range(4, upperbound, 2)),relative=False)
plt.savefig('./img/Fig10.png')
plt.close()


voter_start=10
max_voters=201
voter_step_size=5
candidate_list = [10,25,50]
num_elections=600
meanCON=election_distance_matrix(sp.get_conitzer_matrix,sp.generate_conitzer_election,'conitzer',num_elections,max_voters,voter_step_size,candidate_list,voter_start=voter_start)
meanWAL=election_distance_matrix(sp.get_walsh_matrix,sp.generate_walsh_election,'walsh',num_elections,max_voters,voter_step_size,candidate_list,voter_start=voter_start)
meanIC=election_distance_matrix(UN,ic.generate_impartial_culture_election,'IC',num_elections,max_voters,voter_step_size,candidate_list,voter_start=voter_start)
meanGSC=election_distance_matrix(gs.get_gs_caterpillar_matrix,gs.generate_group_separable_election,'gs_caterpillar',num_elections,max_voters,voter_step_size,candidate_list,voter_start=voter_start,params={'tree':'caterpillar'})
meanGSB=election_distance_matrix(UN,gs.generate_group_separable_election,'gs_balanced',num_elections,max_voters,voter_step_size,[16,32,64],voter_start=voter_start,params={'tree':'balanced'})

plt.plot(list(range(voter_start, max_voters, voter_step_size)), meanCON, label='Conitzer')
plt.plot(list(range(voter_start, max_voters, voter_step_size)), meanWAL, label='Walsh')
plt.plot(list(range(voter_start, max_voters, voter_step_size)), meanIC, label='IC')
plt.plot(list(range(voter_start, max_voters, voter_step_size)), meanGSC, label='GS/caterpillar')
plt.plot(list(range(voter_start, max_voters, voter_step_size)), meanGSB, label='GS/balanced')
plt.legend()
plt.xlabel('number of voters')
plt.ylabel('normalized mean distance')
plt.savefig('./img/Fig14.png')
plt.close()

#Figure 15
mallows_variance()
