import mapel
import sys

if __name__ == "__main__":

    num_candidates = int(sys.argv[1])
    experiment_id = "skeleton_" + str(num_candidates)

    m = num_candidates
    n = 100

    experiment = mapel.prepare_experiment(experiment_id=experiment_id)
    experiment.prepare_elections()
    experiment.compute_distances()
    dim = 2
    af = 1
    experiment.embed(algorithm="mds", dim=dim, attraction_factor=af)

    names = ["ID", "UN", "AN", "ST", "WAL", "CON", "CAT", "MID"]
    roads = [['UN', 'CON'], ['CON', 'AN'], ['CON', 'WAL'], ['CON', 'ID'],
             ['WAL', 'ID'], ['WAL', 'ST'], ['WAL', 'AN'],
             ['MID', 'AN'], ['MID', 'ID'], ['CON', "CAT"],
             ['CAT', 'AN'], ['CAT', 'UN'], ['UN', 'WAL']]

    saveas = 'skeleton_' + str(num_candidates)
    experiment.print_map(saveas=saveas, ms=25, adjust=True,
                         event='skeleton',
                         legend=False, skeleton=names)











