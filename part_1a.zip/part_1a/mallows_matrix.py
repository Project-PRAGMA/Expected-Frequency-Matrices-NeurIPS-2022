import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from random import choices
from random import randint
import tikzplotlib
import math
import random
from random import randrange
import sys
import copy
import pickle
import os

def nswap(m):
	return int((m * (m - 1)) / 2)


def weighted_choice(choices):
	total = sum(w for c, w in choices)
	r = random.uniform(0, total)
	upto = 0.0
	for c, w in choices:
		if upto + w >= r:
			return c
		upto = upto + w
	assert False, "Shouldn't get here"


def getNumBalls(n, d):
	global S
	total_num = S[n][d]
	population = [x for x in range(min(d, n - 1) + 1)]
	weights = [(S[n - 1][d - x]) / total_num for x in range(min(d, n - 1) + 1)]
	weights = np.array(weights)
	# weights /= weights.sum()
	# norm = [i / sum(weights) for i in weights]
	comb = list(zip(population, weights))
	# draw = np.random.choice(population, 1, p=norm)
	draw = weighted_choice(comb)
	return draw


# return draw[0]


def generateDistribution(n, d):
	bins = [0 for x in range(n - 1)]
	for i in range(n - 1):
		if d == 0:
			bins[i] = 0
		else:
			k = getNumBalls(n - i, d)
			bins[i] = k
			d = d - k
	return bins


def generatePermu(n, d):
	bins = generateDistribution(n, d)
	perm = [-1 for x in range(0, n)]
	ind = [x for x in range(0, n)]
	for j in range(n - 1):
		perm[j] = ind[bins[j]]
		del ind[bins[j]]
	perm[n - 1] = ind[0]
	return perm


def generateVoteSwapArray(m):
	S = [[0 for x in range(int(m * (m + 1) / 2) + 1)] for x in range(m + 1)]

	for n in range(m + 1):
		# print(n)
		for d in range(0, int((n + 1) * n / 2 + 1)):
			if d == 0:
				S[n][d] = 1
			else:
				S[n][d] = S[n][d - 1] + S[n - 1][d] - S[n - 1][d - n]
	return S


# T[mm,k,i,j] number of votes over mm candidates with k inversions where i is ranked in position j
def generatePositionArray(m, S):
	t_swaps = int(m * (m - 1) / 2 + 1)
	print('START')
	T = [[[[0 for x in range(m)] for x in range(m)] for x in range(t_swaps)] for x in range(m + 1)]
	print('END')
	for mm in range(m + 1):
		for k in range(t_swaps):
			for i in range(m):
				for j in range(m):
					T[mm][k][i][j] = 0

	T[1][0][0][0] = 1
	for mm in range(2, m + 1):
		print(mm)
		for k in range(int(mm * (mm - 1) / 2 + 1)):
			for i in range(mm):
				for j in range(mm):
					if i == mm - 1:
						T[mm][k][i][j] = S[mm - 1][k - (i - j)]
					else:
						for p in range(j):
							T[mm][k][i][j] = T[mm][k][i][j] + T[mm - 1][k - (mm - p - 1)][i][j - 1]
						for p in range(j + 1, mm):
							T[mm][k][i][j] = T[mm][k][i][j] + T[mm - 1][k - (mm - p - 1)][i][j]

	return T


# print(T[m,10])


# arr=np.arange(100*100*100*99/2, dtype='int32').reshape((100,int(100*99/2),100))
# print(sys.getsizeof(arr), sys.getsizeof(arr))
# exit()
def generatePositionArray2(m, S):
	dir="./aaai_map_of_elections/mapel/voting/elections/mallows_positionmatrices"
	if not os.path.exists(dir):
		os.makedirs(dir)
	# t_swaps = int(m * (m - 1) / 2 + 1)
	T2 = [[[0 for x in range(1)] for x in range(1)] for x in range(int(1 * (1 - 1) / 2 + 1))]
	T2[0][0][0] = 1
	with open("./aaai_map_of_elections/mapel/voting/elections/mallows_positionmatrices/" + str(30) + "_matrix.txt", "rb") as file:
		T2 = pickle.load(file)
	for mm in range(81, m + 1):
		T1 = [[[0 for x in range(mm)] for x in range(mm)] for x in range(int(mm * (mm - 1) / 2 + 1))]
		print(mm)
		for k in range(int(mm * (mm - 1) / 2 + 1)):
			for i in range(mm):
				for j in range(mm):
					if i == mm - 1:
						T1[k][i][j] = S[mm - 1][k - (i - j)]
						#T1[k][i][j] =0
					else:
						for p in range(j):
							if k - (mm - p - 1) < int((mm - 1) * (mm - 2) / 2 + 1) and k - (mm - p - 1)>=0:
								T1[k][i][j] = T1[k][i][j] + T2[k - (mm - p - 1)][i][j - 1]
								#T1[k][i][j] = 0
						for p in range(j + 1, mm):
							if k - (mm - p - 1) < int((mm - 1) * (mm - 2) / 2 + 1) and k - (mm - p - 1)>=0:
								T1[k][i][j] = T1[k][i][j]+ T2[k - (mm - p - 1)][i][j]
		with open("./aaai_map_of_elections/mapel/voting/elections/mallows_positionmatrices/"+str(mm)+"_matrix.txt", "wb") as file:
			pickle.dump(T1, file)
		#with open("./positionmat/"+str(mm)+"_matrix.txt", "rb") as file:
		#	lll = pickle.load(file)
		#print(lll)
		T2 = copy.deepcopy(T1)
	return T1

'''
m = 100
S = generateVoteSwapArray(m)
# print(S)
print(generatePositionArray2(m, S))
exit()
Pos = [[0 for x in range(m)] for x in range(m)]
tot = 1000000
total = S[m][t]
for i in range(tot):
	v = generatePermu(m, t)
	# print(v)
	for i, mm in enumerate(v):
		Pos[mm][i] = Pos[mm][i] + 1

for i in range(m):
	for j in range(m):
		Pos[i][j] = Pos[i][j] * (total / tot)
print(Pos)
'''

def calculateZpoly(m):
	res = [1]
	for i in range(1, m + 1):
		mult = [1] * i
		res2 = [0] * (len(res) + len(mult) - 1)
		for o1, i1 in enumerate(res):
			for o2, i2 in enumerate(mult):
				res2[o1 + o2] += i1 * i2
		res = res2
	return res


def evaluatePolynomial(coeff, x):
	res = 0
	for i, c in enumerate(coeff):
		res += c * (x ** i)
	return res


def calculateZ(m, phi):
	coeff = calculateZpoly(m)
	# print(coeff)
	return evaluatePolynomial(coeff, phi)


def calcPoly(swap_array, m):
	coeff = (nswap(m) + 1) * [0]
	for i in range(nswap(m) + 1):
		coeff[i] = swap_array[i]
	return coeff


def calculateRelativeExpected(m, phi):
	expect = calcExpect(S[m], phi, m)
	Z = calculateZ(m, phi)
	# print(expect)
	# print(Z)
	a_res = expect / Z
	r_res = a_res / nswap(m)
	# print(r_res)
	return a_res, r_res


def mallowsMatrix(m, phi, pos):
	mat = [[0 for i in range(m)] for j in range(m)]
	Z = calculateZ(m, phi)
	# print(Z)
	for i in range(m):
		for j in range(m):
			freqs = [pos[k][i][j] for k in range(1 + int(m * (m - 1) / 2))]
			# print(freqs)
			unnormal_prob = evaluatePolynomial(freqs, phi)
			# print(unnormal_prob)
			mat[i][j] = unnormal_prob / Z
	return mat


def emd(vector_1, vector_2, num_candidates):
	dirt = 0.
	for i in range(num_candidates - 1):
		surplus = vector_1[i] - vector_2[i]
		dirt += abs(surplus)
		vector_1[i + 1] += surplus
	return dirt


def emd_matrix(mat1, mat2, num_canidates):
	# print(mat1)
	# print(mat2)
	costs = []
	for i in range(num_canidates):
		cost = []
		for j in range(num_canidates):
			#print(mat1[i])
			#print(mat2[j])
			cost.append(emd(mat1[i].copy(), mat2[j].copy(), num_canidates))
			#print(cost)
		costs.append(cost)
	costs = np.array(costs)
	#print(costs)
	row_ind, col_ind = linear_sum_assignment(costs)
	return costs[row_ind, col_ind].sum()


def computeInsertionProbas(i, phi):
	probas = (i + 1) * [0]
	for j in range(i + 1):
		probas[j] = pow(phi, (i + 1) - (j + 1))
	return probas


def mallowsModel(m, phi):
	vote = [0]
	for i in range(1, m):
		population = list(range(i + 1))
		we = computeInsertionProbas(i, phi)
		# print(we)
		weights = [w / sum(we) for w in we]
		# print(population)
		# print(weights)
		index = choices(population, weights)
		# print(index)
		vote.insert(index[0], i)
	return vote


def mallowsElectionMat(n, m, phi):
	ar = [[0 for i in range(m)] for j in range(m)]
	for i in range(n):
		pref = mallowsModel(m, phi)
		for j in range(m):
			ar[pref[j]][j] += 1
	res = [[ar[i][j] / n for i in range(m)] for j in range(m)]
	# print(res)
	return res


def getInvCount(arr, n):
	inv_count = 0
	for i in range(n):
		for j in range(i + 1, n):
			if (arr[i] > arr[j]):
				inv_count += 1

	return inv_count


# Given the number m of candidates and a phi\in [0,1] function computes the expected number of swaps in a vote sampled from Mallows model
def calculateExpectedNumberSwaps(m, phi):
	res = phi * m / (1 - phi)
	for j in range(1, m + 1):
		res = res + (j * (phi ** j)) / ((phi ** j) - 1)
	return res


# Given the number m of candidates and a absolute number of expected swaps exp_abs, this function returns a value of phi such that in a vote sampled from Mallows model with this parameter the expected number of swaps is exp_abs
def binary_search_phi(m, exp_abs):
	low = 0
	high = 1
	if exp_abs==m*(m-1)/4:
		return 1
	while low <= high:
		# print(low)
		# print(high)
		mid = (high + low) / 2
		cur = calculateExpectedNumberSwaps(m, mid)
		if abs(cur - exp_abs) < 1e-5:
			return mid
		# If x is greater, ignore left half
		if cur < exp_abs:
			low = mid

		# If x is smaller, ignore right half
		elif cur > exp_abs:
			high = mid

	# If we reach here, then the element was not present
	return -1


def matrix_dist(m):
	ID = []
	UN = []
	AN = []
	ST = []
	for i in range(m):
		tmp = [0] * m
		tmp[i] = 1
		ID.append(tmp)
		UN.append([1.0 / m] * m)
		tmpp = [0] * m
		tmpp[i] = 0.5
		tmpp[m - i - 1] = 0.5
		AN.append(tmpp)
		if i < (m / 2):
			tmp1 = [2 / m] * int(m / 2)
			tmp2 = [0] * int(m / 2)
			ST.append(tmp1 + tmp2)
		else:
			tmp1 = [0] * int(m / 2)
			tmp2 = [2 / m] * int(m / 2)
			ST.append(tmp1 + tmp2)
	norm = (1 / 3) * (m * m - 1)
	with open("/local/users/n.boehmer/positionmat/" + str(m) + "_matrix.txt", "rb") as file:
		pos = pickle.load(file)
	t = 51
	ar = [[0 for i in range(t)] for j in range(6)]
	# for i, m in enumerate(np.linspace(10, 100, k, dtype=int)):
	for j, lp in enumerate(np.linspace(0, 1, t)):
		print(j)
		phi = binary_search_phi(m, lp * m * (m - 1) / 4)
		mat = mallowsMatrix(m, phi, pos)
		ar[0][j] = emd_matrix(ID, mat, m) / norm
		ar[1][j] = emd_matrix(UN, mat, m) / norm
		ar[2][j] = emd_matrix(AN, mat, m) / norm
		ar[3][j] = emd_matrix(ST, mat, m) / norm
		ar[4][j] = ar[0][j] + ar[1][j]
		ar[5][j] = ar[2][j] + ar[3][j]
	for i, m in enumerate(['ID', 'UN', 'AN', 'ST', 'ID+UN', 'AN+ST']):
		# print(i)
		# print(ar[i])
		plt.plot(np.linspace(0, 1, t), ar[i], label=str(m))
		plt.legend()
	plt.xlabel('phi')
	plt.ylabel('normalized distance')
	# plt.show()
	plt.savefig('mallowsDist.png')
	plt.close()


def matrix_distphi(phi, pos):
	# num different phi
	t = 14
	ar = [[0 for i in range(t)] for j in range(6)]
	# for i, m in enumerate(np.linspace(10, 100, k, dtype=int)):
	for j in range(t):
		m = 2 * j + 4
		print(m)
		ID = []
		UN = []
		AN = []
		ST = []
		for i in range(m):
			tmp = [0] * m
			tmp[i] = 1
			ID.append(tmp)
			UN.append([1.0 / m] * m)
			tmpp = [0] * m
			tmpp[i] = 0.5
			tmpp[m - i - 1] = 0.5
			AN.append(tmpp)
			if i < (m / 2):
				tmp1 = [2 / m] * int(m / 2)
				tmp2 = [0] * int(m / 2)
				ST.append(tmp1 + tmp2)
			else:
				tmp1 = [0] * int(m / 2)
				tmp2 = [2 / m] * int(m / 2)
				ST.append(tmp1 + tmp2)
		norm = (1 / 3) * (m * m - 1)
		with open("/local/users/n.boehmer/positionmat/" + str(m) + "_matrix.txt", "rb") as file:
			pos = pickle.load(file)
		mat = mallowsMatrix(m, phi, pos)
		ar[0][j] = emd_matrix(ID, mat, m) / norm
		ar[1][j] = emd_matrix(UN, mat, m) / norm
		ar[2][j] = emd_matrix(AN, mat, m) / norm
		ar[3][j] = emd_matrix(ST, mat, m) / norm
		ar[4][j] = ar[0][j] + ar[1][j]
		ar[5][j] = ar[2][j] + ar[3][j]
	for i, m in enumerate(['ID', 'UN', 'AN', 'ST', 'ID+UN', 'AN+ST']):
		# print(i)
		# print(ar[i])
		plt.plot(list(range(4, 2 * (t - 1) + 4 + 1, 2)), ar[i], label=str(m))
		plt.legend()
	plt.xlabel('m')
	plt.ylabel('normalized distance')
	# plt.show()
	plt.savefig('mallowsDistphi' + str(phi) + '.png')
	plt.close()


def matrix_distnormphi(nphi):
	# num different phi
	t = 38
	ar = [[0 for i in range(t)] for j in range(6)]
	# for i, m in enumerate(np.linspace(10, 100, k, dtype=int)):
	for j in range(t):
		m = 2 * j + 4
		print(m)
		phi = binary_search_phi(m, nphi * m * (m - 1) / 2)
		ID = []
		UN = []
		AN = []
		ST = []
		for i in range(m):
			tmp = [0] * m
			tmp[i] = 1
			ID.append(tmp)
			UN.append([1.0 / m] * m)
			tmpp = [0] * m
			tmpp[i] = 0.5
			tmpp[m - i - 1] = 0.5
			AN.append(tmpp)
			if i < (m / 2):
				tmp1 = [2 / m] * int(m / 2)
				tmp2 = [0] * int(m / 2)
				ST.append(tmp1 + tmp2)
			else:
				tmp1 = [0] * int(m / 2)
				tmp2 = [2 / m] * int(m / 2)
				ST.append(tmp1 + tmp2)
		norm = (1 / 3) * (m * m - 1)
		with open("/local/users/n.boehmer/positionmat/"+str(m)+"_matrix.txt", "rb") as file:
			pos = pickle.load(file)
		mat = mallowsMatrix(m, phi, pos)
		ar[0][j] = emd_matrix(ID, mat, m) / norm
		ar[1][j] = emd_matrix(UN, mat, m) / norm
		ar[2][j] = emd_matrix(AN, mat, m) / norm
		ar[3][j] = emd_matrix(ST, mat, m) / norm
		ar[4][j] = ar[0][j] + ar[1][j]
		ar[5][j] = ar[2][j] + ar[3][j]
	for i, m in enumerate(['ID', 'UN', 'AN', 'ST', 'ID+UN', 'AN+ST']):
		# print(i)
		# print(ar[i])
		plt.plot(list(range(4, 2 * (t - 1) + 4 + 1, 2)), ar[i], label=str(m))
		plt.legend()
	plt.xlabel('m')
	plt.ylabel('normalized distance')
	# plt.show()
	plt.savefig('mallowsDistphinorm' + str(nphi) + '.png')
	plt.close()

matrix_dist(30)
#matrix_distnormphi(0.3)
exit()
print(emd_matrix([[1, 0, 0], [0, 1, 0], [0, 0, 1]], [[0.44667154740928494, 0.8928498869646537, 0.6360621910021245],
													 [0.2164594822761775, 0.021583433243972827, 0.05208203528449207],
													 [0.9727596566225859, 0.7568747786336246, 0.5030848705498369]]
				 , 3))
exit()
m = 20
S = generateVoteSwapArray(m)
ID = []
UN = []
AN = []
ST = []
for i in range(m):
	tmp = [0] * m
	tmp[i] = 1
	ID.append(tmp)
	UN.append([1.0 / m] * m)
	tmpp = [0] * m
	tmpp[i] = 0.5
	tmpp[m - i - 1] = 0.5
	AN.append(tmpp)
	if i < (m / 2):
		tmp1 = [2 / m] * int(m / 2)
		tmp2 = [0] * int(m / 2)
		ST.append(tmp1 + tmp2)
	else:
		tmp1 = [0] * int(m / 2)
		tmp2 = [2 / m] * int(m / 2)
		ST.append(tmp1 + tmp2)

matrix_dist(m, ID, UN, AN, ST)
S = generateVoteSwapArray(30)
pos = generatePositionArray(30, S)
