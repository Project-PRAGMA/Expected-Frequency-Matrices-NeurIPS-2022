import numpy as np
import sys
import copy
import pickle
import os

def generateVoteSwapArray(m):
	S = [[0 for x in range(int(m * (m + 1) / 2) + 1)] for x in range(m + 1)]

	for n in range(m + 1):
		# print(n)
		for d in range(0, int((n + 1) * n / 2 + 1)):
			if d == 0:
				S[n][d] = 1
			else:
				S[n][d] = S[n][d - 1] + S[n - 1][d] - S[n - 1][d - n]
	return S


def generatePositionArray(m, S):
	dir="./mapel/voting/elections/mallows_positionmatrices"
	if not os.path.exists(dir):
		os.makedirs(dir)
	T2 = [[[0 for x in range(1)] for x in range(1)] for x in range(int(1 * (1 - 1) / 2 + 1))]
	T2[0][0][0] = 1
	with open("./mapel/voting/elections/mallows_positionmatrices/" + str(30) + "_matrix.txt", "rb") as file:
		T2 = pickle.load(file)
	for mm in range(31, m + 1):
		T1 = [[[0 for x in range(mm)] for x in range(mm)] for x in range(int(mm * (mm - 1) / 2 + 1))]
		print(mm)
		for k in range(int(mm * (mm - 1) / 2 + 1)):
			for i in range(mm):
				for j in range(mm):
					if i == mm - 1:
						T1[k][i][j] = S[mm - 1][k - (i - j)]
					else:
						for p in range(j):
							if k - (mm - p - 1) < int((mm - 1) * (mm - 2) / 2 + 1) and k - (mm - p - 1)>=0:
								T1[k][i][j] = T1[k][i][j] + T2[k - (mm - p - 1)][i][j - 1]
						for p in range(j + 1, mm):
							if k - (mm - p - 1) < int((mm - 1) * (mm - 2) / 2 + 1) and k - (mm - p - 1)>=0:
								T1[k][i][j] = T1[k][i][j]+ T2[k - (mm - p - 1)][i][j]
		with open("./mapel/voting/elections/mallows_positionmatrices/"+str(mm)+"_matrix.txt", "wb") as file:
			pickle.dump(T1, file)
		T2 = copy.deepcopy(T1)
	return T1
