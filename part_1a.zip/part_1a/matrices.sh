python3 matrix2png.py $1 conitzer_matrix org
python3 matrix2png.py $1 walsh_matrix org
python3 matrix2png.py $1 walsh_matrix ID
python3 matrix2png.py $1 gs_caterpillar_matrix org
python3 matrix2png.py $1 gs_caterpillar_matrix AN
python3 matrix2png.py $1 mallows ID 0.1
python3 matrix2png.py $1 mallows ID 0.5

