import mapel
import csv

MODELS = [
    'sushi',
    'irish',
    'glasgow',
    'skate',
    'tshirt',
    'cities_survey',
    'aspen',
    'ers',
    'cycling_tdf',
    'cycling_gdi',
    'speed_skating'
]


def approx_preflib_with_skeleton():

    experiment_id = 'preflib'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                          instance_type=instance_type,
                                          clean=False,
                                          distance_id=distance_id)

    with open("additional_data/results_mallows_2.csv", 'w') as csv_file:
        line = f'election_id;norm-phi;distance;ranking\n'
        csv_file.write(line)
        for model in MODELS:
            for i in range(15):
                name = f'{model}_{i}'
                ele_1 = experiment.elections[name]

                output = {}
                rankings = {}
                for j in range(1001):
                    norm_phi = j/1000.

                    ele_2 = mapel.generate_election(model_id='norm-mallows_matrix',
                                                    num_voters=100,
                                                    num_candidates=10,
                                                    params={'norm-phi': norm_phi, 'weight': 0})
                    value = mapel.compute_distance(ele_1, ele_2, distance_id='emd-positionwise')
                    output[str(norm_phi)] = value[0]
                    rankings[str(norm_phi)] = value[1]

                best_key = min(output, key=output.get)
                line = f'{name};{best_key};{output[best_key]};{rankings[best_key]}\n'
                print(line)
                csv_file.write(line)


def sanity_check_1():

    experiment = mapel.prepare_experiment(experiment_id='sanity_check')

    precision = 1000

    data = {}
    for election_id in experiment.elections:
        ele_1 = experiment.elections[election_id]

        output = {}
        for j in range(precision+1):
            norm_phi = j/precision

            ele_2 = mapel.generate_election(model_id='norm-mallows_matrix',
                                            num_voters=100,
                                            num_candidates=10,
                                            params={'norm-phi': norm_phi, 'weight': 0})
            value = mapel.compute_distance(ele_1, ele_2, distance_id='emd-positionwise')
            output[str(norm_phi)] = value[0]

        best_key = min(output, key=output.get)
        print(f'{election_id};{best_key};{output[best_key]}')

        data[election_id] = float(best_key)


def sanity_check_2():

    experiment_id = 'sanity_check_sym_mixture'

    experiment = mapel.prepare_experiment(experiment_id=experiment_id)

    experiment.prepare_elections()

    precision_normphi = 20
    precision_weight = 20

    A = [0.1, 0.2, 0.3, 0.4, 0.5]
    B = [(i + 1) / 20 for i in range(19)]

    all = []
    for a in A:
        for b in B:
            all.append(f'{b}; {a}')
    ctr = 0

    for election_id in experiment.elections:
        ele_1 = experiment.elections[election_id]

        output = {}

        for p1 in range(precision_normphi + 1):
            normphi = p1 / float(precision_normphi)

            for w in range(int(precision_weight / 2 + 1)):
                weight = w / float(precision_weight)

                ele_2 = mapel.generate_election(model_id='norm-mallows_matrix',
                                                num_voters=100,
                                                num_candidates=10,
                                                params={'norm-phi': normphi,
                                                        'sec_norm-phi': normphi,
                                                        'weight': weight})
                value = mapel.compute_distance(ele_1, ele_2, distance_id='emd-positionwise')
                output[f'{normphi}; {weight}'] = value[0]

        best_key = min(output, key=output.get)
        print(all[ctr])
        default = output[str(all[ctr])]
        print(f'{best_key}; {round(output[best_key], 4)}; {round(default - output[best_key], 4)}')
        print("===")
        ctr += 1


def approx_preflib_with_mallows():

    experiment_id = 'preflib'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                          instance_type=instance_type,
                                          clean=False,
                                          distance_id=distance_id)

    precision_normphi = 20
    precision_weight = 20

    for model in MODELS:
        for i in range(15):
            name = f'{model}_{i}'

            ele_1 = experiment.elections[name]

            output = {}
            for p1 in range(precision_normphi+1):
                normphi = p1 / float(precision_normphi)

                for w in range(int(precision_weight/2+1)):
                    weight = w / float(precision_weight)

                    ele_2 = mapel.generate_election(model_id='norm-mallows_matrix',
                                                    num_voters=100,
                                                    num_candidates=10,
                                                    params={'norm-phi': normphi,
                                                            'sec_norm-phi': normphi,
                                                            'weight': weight})
                    value = mapel.compute_distance(ele_1, ele_2, distance_id='emd-positionwise')
                    output[f'{normphi};{weight}'] = value[0]

            best_key = min(output, key=output.get)
            print(f'{name};{best_key};{output[best_key]}')


def approx_preflib_with_sp():

    experiment_id = 'preflib'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                          instance_type=instance_type,
                                          clean=False,
                                          distance_id=distance_id)



    precision_normphi_1 = 20
    for model in MODELS:
        for i in range(15):
            name = f'{model}_{i}'

            ele_1 = experiment.elections[name]

            output = {}
            for p1 in range(precision_normphi_1+1):
                normphi_1 = p1 / float(precision_normphi_1)


                ele_2 = mapel.generate_election(model_id='walsh_path',
                                                num_voters=100,
                                                num_candidates=10,
                                                params={'norm-phi': normphi_1,
                                                        'weight': 0})
                value = mapel.compute_distance(ele_1, ele_2, distance_id='emd-positionwise')
                output[f'{normphi_1}'] = value[0]

            best_key = min(output, key=output.get)
            print(f'{name};{best_key};{output[best_key]}')


if __name__ == "__main__":

    # Compute distances to closest skeleton elections
    approx_preflib_with_skeleton()

    # Sanity check with one-param optimization
    sanity_check_1()
    # Sanity check with two-params optimization
    sanity_check_2()

    # Approximate Preflib elections
    approx_preflib_with_mallows()
    approx_preflib_with_sp()




