from scipy.stats import stats

import csv
import os
import mapel
import matplotlib.pyplot as plt
import tikzplotlib

MODELS = [
    'sushi',
    'irish',
    'glasgow',
    'skate',
    'tshirt',
    'cities_survey',
    'aspen',
    'ers',
    'cycling_tdf',
    'cycling_gdi',
    'speed_skating'
]

def norm_phi_from_phi(phi=None, num_candidates=10):
    res = phi * num_candidates / (1 - phi)
    for j in range(1, num_candidates + 1):
        res = res + (j * (phi ** j)) / ((phi ** j) - 1)
    return res / ((num_candidates * (num_candidates - 1)) / 4)


if __name__ == "__main__":

    # print correlation

    experiment_id = 'additional_data'
    instance_type = 'ordinal'
    distance_id = 'emd-positionwise'

    experiment = mapel.prepare_experiment(experiment_id=experiment_id,
                                          instance_type=instance_type,
                                          clean=False,
                                          distance_id=distance_id)



    fig = plt.figure(figsize=(6.4, 6.4))
    ax = fig.add_subplot()

    data = {}

    with open("additional_data/results_mallows.csv", 'r') as csv_file:
        reader = csv.DictReader(csv_file, delimiter=';')
        for i, row in enumerate(reader):
            data[row['election_id']] = float(row['norm-phi'])

    for model in MODELS:
        X = []
        Y = []
        for i in range(15):
            name = f'{model}_{i}'
            path = f'additional_data/elections-consensus-phis/{name}.phi-est'
            with open(path, 'r') as txt_file:
                phi = float(txt_file.readline())
                norm_phi = norm_phi_from_phi(phi=phi)
                X.append(data[name])
                Y.append(norm_phi)

        plt.scatter(X,Y, label=model.replace('_',' '), alpha=0.75, s=14)

    pcc = round(stats.pearsonr(X, Y)[0], 3)
    pcc_text = f'PCC = {pcc}'
    plt.text(0.7, 0.25, pcc_text, transform=ax.transAxes, size=14)

    plt.legend()
    plt.xlabel('Positionwise approach', size=18)
    plt.ylabel('Kemeny approach', size=18)
    plt.xlim([0,1])
    plt.ylim([0,1])
    path = os.path.join(os.getcwd(), "images", "correlation_preflib")
    plt.savefig(path)
    tikzplotlib.save(path)
    plt.show()

