import java.util.Arrays;


public class Ranking {
	
	public 	String 	vote;
	public  int[]	permutation;
	public	int 	kt_distance;
	
	public Ranking(String vote, int[] permutation, int kt_distance) {
		this.vote = vote;
		this.permutation = permutation;
		this.kt_distance = kt_distance;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + kt_distance;
		result = prime * result + Arrays.hashCode(permutation);
		result = prime * result + ((vote == null) ? 0 : vote.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ranking other = (Ranking) obj;
		if (kt_distance != other.kt_distance)
			return false;
		if (!Arrays.equals(permutation, other.permutation))
			return false;
		if (vote == null) {
			if (other.vote != null)
				return false;
		} else if (!vote.equals(other.vote))
			return false;
		return true;
	}
	
	
	
	
	
				
}
