
public class OutputFormatter {

	public static String ArrayToElectionFormat (int[] a){
		String result="";
		for (int i = 0; i < a.length-1; i++){
			result+=String.valueOf(a[i])+">";
		}
		result+=String.valueOf(a[a.length-1]);
		return result;
	}
	
	public static String ArrayToString (int[] a){
		String result="";
		for (int i = 0; i < a.length; i++){
			result+=String.valueOf(a[i]);
		}
		return result;
	}
	
}
