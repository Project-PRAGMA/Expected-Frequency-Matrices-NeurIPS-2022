#~/bin/bash
JARexecutable="RankingSampler.jar";
if [ "$1" == "clean" ]; then
  for javafile in $(ls *.java);
  do
    classfile="${javafile%*.java}.class";
    if [ -f $classfile ]; then
      rm $classfile;
    fi
  done
  if [ -f $JARexecutable ]; then
    rm $JARexecutable;
  fi
else
  javac -g -cp colt.jar *.java;
  jar -cvfm $JARexecutable Manifest.txt *.class
fi
