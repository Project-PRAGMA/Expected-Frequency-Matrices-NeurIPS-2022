import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
//import java.util.Random;

import cern.jet.random.engine.RandomEngine;
import cern.jet.random.sampling.RandomSampler;
import cern.jet.random.engine.MersenneTwister;
import cern.jet.random.Uniform;



public class RandomSamplers {
	
	/**
	 * Computes a sorted random subset of n elements from the interval [0,N-1].
	 * No element will occur more than once. 
	 * Uses the sample method from the Class cern.jet.random.sampling.RandomSampler in the Colt 1.2.0 Library
	 * (http://acs.lbl.gov/software/colt/)
	 * 
	 * @param n size of the computed random subset 
	 * @param N parameter that defines the interval [0,N-1] from which to sample
	 * @param seedFactor parameter to spread the seed of the random generator
	 * @return the sorted random subset 
	 */
	public static int[] sampleRandomSubset(int n, int N, String seedFactor){
		long[] resultLongArray = null;
		resultLongArray = new long[n];
		int[] result = new int[n];
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RandomEngine randomGenerator = new MersenneTwister(new Date().hashCode()^seedFactor.hashCode());
		RandomSampler.sample(n, N, n, 0, resultLongArray, 0, randomGenerator);
		// cast the result to a int-array
		for (int i = 0; i < n; i++){
			result[i]= (int)resultLongArray[i];
		}
		return result;
	}
	
	/**
	 * Generates a random ranking by randomly permuting the ranking [1 2 ... N].
	 * All permutations occur with approximately equal likelihood.
	 * Uses the shuffle method from the Class java.util.Collections in the Java Platform Standard Edition 6 
	 * (http://docs.oracle.com/javase/6/docs/api/)
	 * 
	 * @param N parameter that defines the ranking [1 2 ... N] to permute
	 * @return the random ranking
	 */
	public static int[] generateRandomRanking (int N){
		ArrayList<Integer> resultArrayList = new ArrayList<Integer>();
		for (int i = 0; i < N; i++){
			resultArrayList.add(new Integer(i+1));
		}
		Collections.shuffle(resultArrayList);
		Object[] resultArray = resultArrayList.toArray();
		int[] result = new int[N];
		// cast the result to a int-array
		for (int i = 0; i < N; i++){
			result[i]= ((Integer)resultArray[i]).intValue();
		}
		return result;		
	}
	
	/**
	 * Generates a random double from a uniform(0,1) distribution.
	 * The generated number excludes 0 and 1.
	 * Uses the nextDoubleFromTo method from the Class cern.jet.random.Uniform in the Colt 1.2.0 Library
	 * (http://acs.lbl.gov/software/colt/)
	 * 
	 * @param seedFactor parameter to spread the seed of the random generator
	 * @return the uniform deviate from ]0,1[
	 */
	public static double generateUniformDeviate(String seedFactor){
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RandomEngine randomGenerator = new MersenneTwister(new Date().hashCode()^seedFactor.hashCode());
		Uniform uniformDistribution = new Uniform(randomGenerator);
		return uniformDistribution.nextDoubleFromTo(0.0,1.0);
		
		// the following alternative implementation using the Class java.util.Random 
		// does not seem to work well:
//		Random random = null;
//		random = new Random (new Date().getTime());
//		return random.nextDouble();	
	}

}
