import java.math.BigInteger;


public class KendallTau {

	/*
	 * (inspired by http://introcs.cs.princeton.edu/java/14array/KendallTau.java.html)
	 */
	public static int KendallTauDistance(int[] a, int[] b){
		
	int N = a.length;
	if ( N!= b.length){
		System.out.println("! ERROR Evaluating KendallTauDistance !");
	}
		
        int[] inv = new int[N];
        for (int i = 0; i < N; i++){
        	inv[a[i]-1] = i;
        }
                    
        int tau = 0;
        for (int i = 0; i < N; i++) {
            for (int j = i+1; j < N; j++) {
                if (inv[b[i]-1] > inv[b[j]-1]){
                	tau++;
                }                	
            }
        }
        
        return tau;
	}
	
	/*
	 * c(n,k) is the number of rankings of size n with at most a Kendall-tau-distance equal to k to a reference ranking  
	 * (inspired by http://stackoverflow.com/questions/948341/dynamic-programming-number-of-ways-to-get-at-least-n-bubble-sort-swaps)
	 * Examples:
	 * c(3, 2)= 5
	 * c(10, 45)= 3628800
	 * c(10, 46)= 3628800
	 * c(10000, 0)= 1
	 * Note: c(100, 15)= 2045850717756467584 (the long max value is nearly exceeded!) 
	 */
	public static BigInteger c(int n, int k){
		
		// Not dynamic programming version of the algorithm with result as a long (not memory efficient):
		/*
		long result;
		k = Math.min(k, n*(n-1)/2 );
		if ( k < 0 ){
			result = 0;
		}
		else if ( k == 0 && n == 0){
			result = 1;
		}
		else{
			result = c(n, k-1)+c(n-1,k)-c(n-1,k-n);
		}
		return result;
		*/		
		

		if(k<0) return new BigInteger("0");
		k = Math.min(k, n*(n-1)/2 );
		
		BigInteger [][] c = new BigInteger [k+1][n+1];
		
		for (int i=0; i<=k; i++){
			for (int j=0; j<=n; j++){
				if(i==0) 		c[i][j] = new BigInteger("1");
				else if(j==0) 	        c[i][j] = new BigInteger("1");
				else if(i>=j) 	        c[i][j] = (c[i-1][j].add(c[i][j-1])).subtract(c[i-j][j-1]);
				else 		 	c[i][j] = (c[i-1][j].add(c[i][j-1]));
			}
		}
		
		return c[k][n];
		
	}
	
	/*
	 * NumberOfPerm(n, k) is the number of possible rankings of size n with a given  Kendall-Tau-distance k to a reference ranking
	 * Examples:
	 * NumberOfPerm(3, 0)= 1
	 * NumberOfPerm(3, 1)= 2
	 * NumberOfPerm(3, 2)= 2
	 * NumberOfPerm(3, 3)= 1
	 * NumberOfPerm(3, 4)= 0
	 * NumberOfPerm(10000, 0)= 1
	 * NumberOfPerm(10, 10*9/2)= 1
	 */
	public static BigInteger NumberOfPerm(int n, int k){
		return c(n,k).subtract(c(n,k-1));
	}
	
}
