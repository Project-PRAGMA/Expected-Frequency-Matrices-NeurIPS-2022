#!/bin/bash
./scr_00_prepare_dir.sh
./scr_01_translate-socs.sh
./scr_02_solve.sh
./scr_03_estimate-phis.sh 
#./scr_04_filter-results.sh
#./scr_05-gen-plotfiles.sh