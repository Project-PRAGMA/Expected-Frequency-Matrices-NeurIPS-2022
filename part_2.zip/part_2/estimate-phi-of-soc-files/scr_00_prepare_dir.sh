#!/bin/bash
chmod +x binary/linux/amd64/kconsens
ln -s binary/linux/amd64/kconsens kconsens
ln -s binary/java/RankingSampler.jar RankingSampler.jar
chmod +x scripts/estimate-phi.sh
ln -s scripts/estimate-phi.sh estimate-phi.sh
chmod +x scripts/preflib-soc-2-kconsens-election.py
ln -s scripts/preflib-soc-2-kconsens-election.py preflib-soc-2-kconsens-election.py