#!/bin/bash
for socfile in $(ls preflib-soc/*.soc); do
 ./preflib-soc-2-kconsens-election.py $socfile > ${socfile%soc}election
done