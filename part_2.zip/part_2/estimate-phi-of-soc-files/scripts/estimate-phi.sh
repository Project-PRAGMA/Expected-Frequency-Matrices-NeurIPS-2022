#!/bin/bash
electionfile="$1"
consensusfile="$2"
thetaRAW=$(java -jar RankingSampler.jar estimate-dispersion ${electionfile} ${consensusfile} 1E-9 10000000000 1E-9 false | tail -1);
theta=${thetaRAW/E/*10^}
if [ $(echo "$theta < 0" | bc -l) -eq 1 ] ; then
  echo "ERROR $theta"
  #exit -1
fi
if [ $(echo "$theta > 1000" | bc -l) -eq 1 ] ; then
  echo "0"
else
  phi=$(echo "e(-$theta)" | bc -l)
  echo $phi
fi