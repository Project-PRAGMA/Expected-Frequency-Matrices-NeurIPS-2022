#!/bin/bash
for electionfile in $(ls preflib-soc/*.election); do
 elfile="${electionfile}.anoncomplete"
 cfile="${electionfile}.anoncomplete.consensus-2p"
 phivalue=$(./estimate-phi.sh $elfile $cfile)
 echo $phivalue > ${electionfile%election}phi-est
done