#!/bin/bash

for socfile in $(ls preflib-soc/*.election); do
 ./kconsens -e ${socfile} -p -s -2
 rm ${socfile}.clean
 rm ${socfile}.complete
done
